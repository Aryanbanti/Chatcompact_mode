package com.chatcompact;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

@Mod(modid = "chatcompact", name = "Chat Compact", version = "1.1")
public class ChatCompactMod {

    private String lastMessage = "";
    private int repeatCount = 1;
    private boolean isEnabled = true;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onChatReceived(ClientChatReceivedEvent event) {
        if (!isEnabled) return;

        String message = event.message.getUnformattedText();

        if (message.equalsIgnoreCase(lastMessage)) {
            repeatCount++;
            event.setCanceled(true);
            Minecraft.getMinecraft().thePlayer.addChatMessage(
                new ChatComponentText(message + " x" + repeatCount)
            );
        } else {
            repeatCount = 1;
            lastMessage = message;
        }
    }

    @SubscribeEvent
    public void onClientChat(ClientChatEvent event) {
        String msg = event.message;
        if (msg.equalsIgnoreCase("/chatcompact toggle")) {
            isEnabled = !isEnabled;
            String status = isEnabled ? "enabled" : "disabled";
            Minecraft.getMinecraft().thePlayer.addChatMessage(
                new ChatComponentText("[ChatCompact] Compacting " + status + ".")
            );
            event.setCanceled(true); // Prevent message from reaching server
        }
    }
}
