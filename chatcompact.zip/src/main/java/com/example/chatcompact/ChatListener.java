
package com.example.chatcompact;

import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.ChatComponentText;

public class ChatListener {

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent event) {
        String msg = event.message.getUnformattedText();

        // Compact common ranks and tags
        msg = msg.replace("[MVP++]", "[++]")
                 .replace("[MVP+]", "[+]")
                 .replace("[VIP+]", "[+VIP]")
                 .replace("[MVP]", "[M]")
                 .replace("[VIP]", "[V]")
                 .replace("[Guild]", "[G]")
                 .replace("[Party]", "[P]")
                 .replace("Officer", "Of")
                 .replace("Guild Master", "GM")
                 .replace("Party Leader", "PL");

        event.setMessage(new ChatComponentText(msg));
    }
}
